export class Course {}
