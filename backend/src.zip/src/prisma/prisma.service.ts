import { Injectable, OnModuleInit } from '@nestjs/common';
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  constructor() {
    super({
      adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }),
		max: 10,
		connectionTimeoutMillis: 5000,
		idleTimeoutMillis: 10000,
    });
  }
  async onModuleInit() {
    await this.$connect();
  }
}