export class Exam {}
